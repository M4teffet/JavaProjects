class Main {
    public static void main(String[] args) {
        System.out.print("O X");
        System.out.println(" X");
        System.out.print("O X");
        System.out.println(" O");
        System.out.print("X O");
        System.out.println(" X");
    }
}
