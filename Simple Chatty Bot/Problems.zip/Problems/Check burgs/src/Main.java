import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);

        String str = scan.nextLine();

        System.out.println(str.endsWith("burg"));
    }
}