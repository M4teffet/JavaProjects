import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int busHeight = scan.nextInt();
        int noBridges = scan.nextInt();

        for (int i = 1; i < noBridges + 1; i++) {
            int bridgeHeight = scan.nextInt();

            if (busHeight >= bridgeHeight) {

                System.out.println("Will crash on bridge " + i);
                break;
            }

            if (i == noBridges) {
                System.out.println("Will not crash");
            }

        }
    }
}