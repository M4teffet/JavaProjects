import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String str = "a simple string";

        str = str.replace("a", "A SIMPLE").substring(2, 8);

        System.out.println(str);

    }
}