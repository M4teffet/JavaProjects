class Main {
    public static void main(String[] args)
    {
        System.out.println("first");
        System.out.println("second");
        System.out.println("third");
    }
}