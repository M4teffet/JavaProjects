import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);
        int a = scan.nextInt();
        int b = scan.nextInt();
        long output = 1;

        for (int i = a; i < b; i++) {
            output *= i;

        }
        System.out.println(output);
    }
}