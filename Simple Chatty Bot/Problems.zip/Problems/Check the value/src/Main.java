import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int integer = scanner.nextInt();
        boolean result = integer < 10 && integer > 0;
        System.out.println(result);
    }
}