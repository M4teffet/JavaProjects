import java.util.Scanner;

class Main {
    public static void main(String[] arrg) {
        Scanner scan = new Scanner(System.in);

        double m = scan.nextInt();
        int p = scan.nextInt();
        double k = scan.nextInt();

        int i = 0;

        do {

            if (m < k) {
                m = m * p / 100 + m;
                i++;
            }

        } while (m < k);

        System.out.println(i);
    }
}