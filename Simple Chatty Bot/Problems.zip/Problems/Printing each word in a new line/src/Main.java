import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String textOne = scan.next();
        String textTwo = scan.next();
        String textThree = scan.next();
        String textFour = scan.next();
        String textFive = scan.next();

        System.out.println(textOne + '\n' + textTwo + '\n' + textThree + '\n' + textFour + '\n' + textFive);

    }
}