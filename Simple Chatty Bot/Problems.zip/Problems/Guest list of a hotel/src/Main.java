//put imports you need here

import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String str1 = scan.next();
        String str2 = scan.next();
        String str3 = scan.next();
        String str4 = scan.next();
        String str5 = scan.next();
        String str6 = scan.next();
        String str7 = scan.next();
        String str8 = scan.next();

        System.out.println(str8 + '\n' + str7 + '\n' + str6 + '\n' + str5 + '\n' + str4 + '\n'
                + str3 + '\n' + str2 + '\n' + str1);
    }
}