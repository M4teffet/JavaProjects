class Main {
    public static void main(String[] args) {
        System.out.print("******");
        System.out.println("**");

        System.out.print("      ");
        System.out.println("**");

        System.out.print("      ");
        System.out.println("**");

        System.out.print("      ");
        System.out.println("**");


        System.out.print("**");
        System.out.print("    ");
        System.out.println("**");

        System.out.print("**");
        System.out.print("    ");
        System.out.println("**");

        System.out.print(" ");
        System.out.println("*******");
    }
}