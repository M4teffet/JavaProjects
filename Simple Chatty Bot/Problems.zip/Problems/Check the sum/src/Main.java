import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);

        int a = scan.nextInt();
        int b = scan.nextInt();
        int c = scan.nextInt();
        boolean test = a + b == 20 || a + c == 20 || b + c == 20;
        System.out.println(test);
    }
}