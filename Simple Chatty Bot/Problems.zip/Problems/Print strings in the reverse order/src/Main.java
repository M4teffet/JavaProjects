//put imports you need here
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String nameOne = scanner.nextLine();
        String nameTwo = scanner.nextLine();
        String nameThree = scanner.nextLine();

        System.out.println(nameThree + '\n' + nameTwo + '\n' + nameOne);

    }
}