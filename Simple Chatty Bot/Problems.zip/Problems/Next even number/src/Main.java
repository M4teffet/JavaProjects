import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int a = scanner.nextInt();
        
        int modulo = a % 2;
        
        if (modulo == 0) {
            System.out.println(a + 2);
        } else { 
            System.out.println(a + 1); 
        }
    }
}
