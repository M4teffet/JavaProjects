import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);

        while (scan.hasNext()) {
            int number = scan.nextInt();

            if (number == 0) {
                break;
            } else {
                if (number % 2 == 0) {
                    System.out.println("even");
                } else {
                    System.out.println("odd");
                }
            }
        }

    }
}