import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int c = scanner.nextInt();

        int div = a / 2;

        int div1 = b / 2;

        int div2 = c / 2;

        if (a % 2 != 0) {
            div += 1;
        }

        if (b % 2 != 0) {
            div1 += 1;
        }

        if (c % 2 != 0) {
            div2 += 1;
        }

        System.out.println(div + div1 + div2);
    }
}