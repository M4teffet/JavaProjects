class Main {
    public static void main(String[] arg) {

        int a = 3;
        int b = 6;
            while (b > 0) {
                int c = a % b;
                a = b;
                b = c;
            }
            System.out.println(a);

    }
}
