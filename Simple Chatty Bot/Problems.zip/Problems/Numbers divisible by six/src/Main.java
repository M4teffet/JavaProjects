import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);

        int n = scan.nextInt();
        int output = 0;

        for (int i = 1; i < n + 1; i++) {
            int a = scan.nextInt();

            if (a % 6 == 0) {
                output += a;
            }

        }
        System.out.println(output);
    }
}