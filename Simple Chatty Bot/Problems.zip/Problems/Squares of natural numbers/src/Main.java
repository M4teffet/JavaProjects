import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);

        int n = scan.nextInt();
        int a = 1;

        while (n >= a) {

            if (a * a <= n) {
                System.out.println(a * a);
            }
            a++;
        }

    }
}