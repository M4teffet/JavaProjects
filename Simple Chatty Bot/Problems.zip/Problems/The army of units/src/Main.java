import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);

        int armyUnit = scan.nextInt();

        if (armyUnit < 1) {
            System.out.println("no army");
        } else if (armyUnit <= 19) {
            System.out.println("pack");
        } else if (armyUnit <= 249) {
            System.out.println("throng");
        } else if (armyUnit <= 999) {
            System.out.println("zounds");
        } else {
            System.out.println("legion");
        }
    }
}