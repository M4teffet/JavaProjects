import java.util.Scanner;

class Main {
    public static void main(String[] arg) {
        Scanner scan = new Scanner(System.in);

        int number = scan.nextInt();

        int sum = 0;

        while (number != 0) {

            sum += number;
            number = scan.nextInt();
        }

        System.out.println(sum);
    }
}
