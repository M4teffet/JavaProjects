import javax.print.Doc;

class Army {

    public static void createArmy() {
        Unit unit = new Unit("k19");
        Unit unit1 = new Unit("k19");
        Unit unit2 = new Unit("k19");
        Unit unit3 = new Unit("k19");
        Unit unit4 = new Unit("k19");
        Knight knight = new Knight("mouss");
        Knight knight1 = new Knight("mouss");
        Knight knight2 = new Knight("mouss");
        General general = new General("Mateffet");
        Doctor doctor = new Doctor("Asse");
    }


    // Don't change the code below
    static class Unit {
        static String nameUnit;
        static int countUnit;

        public Unit(String name) {
            countUnit++;
            nameUnit = name;

        }
    }

    static class Knight {
        static String nameKnight;
        static int countKnight;

        public Knight(String name) {
            countKnight++;
            nameKnight = name;

        }
    }

    static class General {
        static String nameGeneral;
        static int countGeneral;

        public General(String name) {
            countGeneral++;
            nameGeneral = name;

        }
    }

    static class Doctor {
        static String nameDoctor;
        static int countDoctor;

        public Doctor(String name) {
            countDoctor++;
            nameDoctor = name;

        }
    }

    public static void main(String[] args) {
        createArmy();
        System.out.println(Unit.countUnit);
        System.out.println(Knight.countKnight);
        System.out.println(General.countGeneral);
        System.out.println(Doctor.countDoctor);
    }

}