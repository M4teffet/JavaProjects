class Book {
    String title;
    int yearOfPublishing;
    boolean isAvailable;
}