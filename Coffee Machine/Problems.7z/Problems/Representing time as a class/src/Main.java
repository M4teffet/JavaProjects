class Time {
    int hours;
    int minutes;
    int seconds;
}