class Patient {

    String name;

    // write your method here
    public void say() {
        System.out.println("Hello, my name is " + this.name + ", I need a doctor.");
    }
}