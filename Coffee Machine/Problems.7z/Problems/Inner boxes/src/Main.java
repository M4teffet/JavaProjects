class Box {
    double length;
    double height;
    double width;
    Box innerBox;
}